
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_places_flutter/google_places_flutter.dart';
import '../model/host_response.dart';
import 'payment_sucess_screen.dart';
import 'paypal_webview.dart';
import '../controller/payment_controller.dart';
import '../controller/user_recomended_list.dart';

class ConfirmBookingScreen extends StatefulWidget {
  final CarItem car;


  const ConfirmBookingScreen({super.key, required this.car});

  @override

  State<ConfirmBookingScreen> createState() => _ConfirmBookingScreenState();
}

enum PaymentMethod {
  card,
  applePay,
  googlePay,
  paypal,
}

late final CarSharingController carSharingController;

class _ConfirmBookingScreenState extends State<ConfirmBookingScreen> {
  final TextEditingController addressCtrl = TextEditingController();
  String? selectedAddress;
  double? selectedLat;
  double? selectedLng;

  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  DateTime? selectedEndDate;
  TimeOfDay? selectedEndTime;

  Duration? get tripDuration {
    if (_startDateTime == null || _endDateTime == null) return null;
    return _endDateTime!.difference(_startDateTime!);
  }


  PaymentMethod selectedPaymentMethod = PaymentMethod.card;

  
  DateTime? get _endDateTime {
    if (selectedEndDate == null || selectedEndTime == null) return null;

    return DateTime(
      selectedEndDate!.year,
      selectedEndDate!.month,
      selectedEndDate!.day,
      selectedEndTime!.hour,
      selectedEndTime!.minute,
    );
  }



  DateTime? get _startDateTime {
    if (selectedDate == null || selectedTime == null) return null;

    return DateTime(
      selectedDate!.year,
      selectedDate!.month,
      selectedDate!.day,
      selectedTime!.hour,
      selectedTime!.minute,
    );
  }



  /// RENT TYPE: Hour / Day
  String rentType = "Hour";

  /// Duration values
  double selectedHours = 1;  // 1–24
  double selectedDays = 1;   // 1–7

  bool collectFromPickup = false; // ✅ MUST be here

  double pickupDistanceMiles = 0.0;
  double pickupCharge = 0.0;

  late DateTime startDateTime;
  late TextEditingController dateCtrl;
  late TextEditingController timeCtrl;

  late final CarSharingController recommendedCtrl;
  late final CarSharingController carSharingController;

  @override
  void initState() {
    super.initState();
    carSharingController = Get.find<CarSharingController>();

    recommendedCtrl = Get.put(CarSharingController());

    startDateTime = DateTime.now();

    dateCtrl = TextEditingController(
      text:
      "${startDateTime.day.toString().padLeft(2, '0')}-"
          "${startDateTime.month.toString().padLeft(2, '0')}-"
          "${startDateTime.year}",
    );

    timeCtrl = TextEditingController();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      timeCtrl.text =
          TimeOfDay.fromDateTime(startDateTime).format(context);
    });
  }




  Widget build(BuildContext context) {
    final car = widget.car;

    final bool isTripSelected =
        _startDateTime != null && _endDateTime != null;

    final double basePrice =
    isTripSelected ? calculateBasePriceFromDuration(car) : 0.0;

    final double pickupFee = collectFromPickup ? pickupCharge : 0.0;

    final double tax = (basePrice + pickupFee) * 0.10;

    final double total = basePrice + pickupFee + tax;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Confirm Booking",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.green.withValues(alpha: 0.75),
        foregroundColor: Colors.white,
      ),

      bottomNavigationBar: _bottomPayButton(total),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            _carDetailsCard(car),

            const SizedBox(height: 22),

            /// 🔹 Collect car toggle
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _sectionTitle("Take to pickup address"),
                Switch(
                  value: collectFromPickup,
                  onChanged: (value) {
                    setState(() {
                      collectFromPickup = value;

                      if (!value) {
                        pickupDistanceMiles = 0;
                        pickupCharge = 0;
                        addressCtrl.clear();
                        selectedAddress = null;
                        selectedLat = null;
                        selectedLng = null;
                      }
                    });
                  },
                ),
              ],
            ),

            const SizedBox(height: 12),

            /// ✅ Show Pickup label + input ONLY when YES
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: collectFromPickup
                  ? Column(
                key: const ValueKey("pickup"),
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionTitle("Pickup Address"),

                  GooglePlaceAutoCompleteTextField(
                    textEditingController: addressCtrl,
                    googleAPIKey: "AIzaSyB08PuFrEY0Hp2GSz4MzGKx18TUSZR8HPI",
                    inputDecoration: InputDecoration(
                      hintText: "Search pickup location",
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),

                    debounceTime: 600, // milliseconds
                    isLatLngRequired: true,

                    getPlaceDetailWithLatLng: (prediction) {
                      setState(() {
                        selectedAddress = prediction.description;
                        selectedLat = double.tryParse(prediction.lat ?? "");
                        selectedLng = double.tryParse(prediction.lng ?? "");

                        // ✅ Ensure both locations exist
                        if (selectedLat != null &&
                            selectedLng != null &&
                            car.lat != null &&
                            car.long != null) {

                          // 📏 Distance in miles
                          pickupDistanceMiles = _calculateDistanceMiles(
                            car.lat! ,
                            car.long!,
                            selectedLat!,
                            selectedLng!,
                          );

                          // 💰 $2 per mile
                          pickupCharge = pickupDistanceMiles * 2;
                        }
                      });

                      debugPrint("📍 Pickup Distance: ${pickupDistanceMiles.toStringAsFixed(2)} miles");
                      debugPrint("💰 Pickup Charge: \$${pickupCharge.toStringAsFixed(2)}");
                    },



                    itemClick: (prediction) {
                      addressCtrl.text = prediction.description ?? "";
                      addressCtrl.selection = TextSelection.fromPosition(
                        TextPosition(offset: addressCtrl.text.length),
                      );
                    },

                    itemBuilder: (context, index, prediction) {
                      return Container(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            const Icon(Icons.location_on, color: Colors.green),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                prediction.description ?? "",
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                          ],
                        ),
                      );
                    },

                    seperatedBuilder: const Divider(),

                    isCrossBtnShown: true,
                  ),

                  const SizedBox(height: 22),
                ],
              )
                  : const SizedBox.shrink(),
            ),

            /// 🔹 Date & Time
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 13),
                _sectionTitle("Trip Start Date"),
                const SizedBox(height: 8),

                LayoutBuilder(
                  builder: (context, constraints) {
                    final double gap = 12;
                    final double itemWidth = (constraints.maxWidth - gap) / 2;

                    return Row(
                      children: [
                        SizedBox(
                          width: itemWidth,
                          child: _datePickerBox(),
                        ),
                        SizedBox(width: gap),
                        SizedBox(
                          width: itemWidth,
                          child: _timePickerBox(),
                        ),
                      ],
                    );
                  },
                ),


              ],
            ),
            const SizedBox(height: 25),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 13),
              _sectionTitle("Trip End Date"),
              const SizedBox(height: 8),

              LayoutBuilder(
                builder: (context, constraints) {
                  final double gap = 12;
                  final double itemWidth = (constraints.maxWidth - gap) / 2;

                  return Row(
                    children: [
                      SizedBox(
                        width: itemWidth,
                        child: _endDateBox(),
                      ),
                      SizedBox(width: gap),
                      SizedBox(
                        width: itemWidth,
                        child:  _endTimeBox(),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),


            const SizedBox(height: 25),
            _sectionTitle("Payment Method"),
            const SizedBox(height: 12),

            _paymentMethodDropdown(),

            const SizedBox(height: 16),

            if (selectedPaymentMethod == PaymentMethod.card)
              _creditCardForm(),


            const SizedBox(height: 22),

            _sectionTitle("Payment Summary"),

            if (!isTripSelected)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  "Select trip start & end time to see price",
                  style: TextStyle(color: Colors.grey),
                ),
              ),

            if (isTripSelected) ...[
              _priceRow(
                "Rental (${rentTypeFromDuration})",
                "\$${basePrice.toStringAsFixed(2)}",
              ),

              if (collectFromPickup)
                _priceRow(
                  "Pickup Charge (${pickupDistanceMiles.toStringAsFixed(2)} miles)",
                  "\$${pickupCharge.toStringAsFixed(2)}",
                ),

              _priceRow("Tax (10%)", "\$${tax.toStringAsFixed(2)}"),

              const Divider(),

              _priceRow(
                "Total",
                "\$${total.toStringAsFixed(2)}",
                bold: true,
              ),
            ],

            const SizedBox(height: 40),
          ],
        ),


      ),
    );
  }

  //    SMALL WIDGETS

  // ---------------------------------------------------------------------------
  // CALCULATE BASE PRICE BASED ON RENT TYPE
  // ---------------------------------------------------------------------------

  double calculateBasePriceFromDuration(CarItem car) {
    final duration = tripDuration;
    if (duration == null) return 0;

    final int totalMinutes = duration.inMinutes;

    const int minutesPerHour = 60;
    const int minutesPerDay = 24 * minutesPerHour;
    const int minutesPerWeek = 7 * minutesPerDay;

    // 🧮 Breakdown
    final int fullWeeks = totalMinutes ~/ minutesPerWeek;
    final int afterWeeks = totalMinutes % minutesPerWeek;

    final int fullDays = afterWeeks ~/ minutesPerDay;
    final int afterDays = afterWeeks % minutesPerDay;

    final int hours =
    (afterDays / minutesPerHour).ceil(); // partial hour charged

    // 💰 Costs (with fallbacks)
    final double hourlyCost = car.hourlyCost ?? 0;
    final double dailyCost =
        car.dailyCost ?? (hourlyCost * 24);
    final double weeklyCost =
        car.weeklyCost ?? (dailyCost * 7);

    // 💵 Price calculation
    final double weekAmount = fullWeeks * weeklyCost;
    final double dayAmount = fullDays * dailyCost;
    final double hourAmount = hours * hourlyCost;

    return weekAmount + dayAmount + hourAmount;
  }


  // double _calculateBasePrice(double hourlyCost) {
  //   if (rentType == "Hour") {
  //     return hourlyCost * selectedHours;
  //   } else {
  //     double costPerDay = hourlyCost * 24;
  //     return costPerDay * selectedDays;
  //   }
  // }

  double _calculateDistanceMiles(
      double lat1,
      double lon1,
      double lat2,
      double lon2,
      ) {
    const earthRadiusMiles = 3958.8;

    double dLat = _degToRad(lat2 - lat1);
    double dLon = _degToRad(lon2 - lon1);

    double a = sin(dLat / 2) * sin(dLat / 2) + cos(_degToRad(lat1)) * cos(_degToRad(lat2)) * sin(dLon / 2) * sin(dLon / 2);

    double c = 2 * atan2(sqrt(a), sqrt(1 - a));

    return earthRadiusMiles * c;
  }

  double _degToRad(double deg) {
    return deg * (pi / 180);
  }

  // ---------------------------------------------------------------------------
  // UI COMPONENTS BELOW (unchanged except auto-updating amounts)
  // ---------------------------------------------------------------------------

  Widget _sectionTitle(String text) {
    return Text(text,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold));
  }

  Widget _carDetailsCard(CarItem car) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            offset: Offset(0, 2),
          )
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              car.picVehicleImage ?? "",
              width: 100,
              height: 130,
              fit: BoxFit.contain, // ✅ no crop
              errorBuilder: (_, __, ___) => Image.asset(
                "assets/images/benz_car.webp",
                width: 130,
                height: 130,
                fit: BoxFit.contain,
              ),
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// 🚗 Car Name
                Text(
                  "${car.vehicle?.make ?? ''} ${car.vehicle?.model ?? ''}",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 6),
                /// 💰 Price
                Text(
                  carSharingController.priceLabel(car),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.green
                  ),
                ),

                const SizedBox(height: 6),

                /// 📍 Car Address
                if ((car.address ?? "").isNotEmpty)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.location_on,
                        size: 14,
                        color: Colors.grey,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          car.address!, // or car.location?.address
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.grey,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _datePickerBox() {
    return GestureDetector(
      onTap: pickDate,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: _boxDecoration(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              selectedDate == null
                  ? "Start Date"
                  : "${selectedDate!.day}-${selectedDate!.month}-${selectedDate!.year}",
              style: const TextStyle(fontSize: 16),
            ),
            const Icon(Icons.calendar_month),
          ],
        ),
      ),
    );
  }

  Widget _timePickerBox() {
    return GestureDetector(
      onTap: pickTime,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: _boxDecoration(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              selectedTime == null
                  ? "Start Time"
                  : selectedTime!.format(context),
              style: const TextStyle(fontSize: 16),
            ),
            const Icon(Icons.access_time),
          ],
        ),
      ),
    );
  }

  Widget _endDateBox() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: pickEndDate, // ✅ correct method
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
          decoration: _boxDecoration(),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  selectedEndDate == null
                      ? "End Date"
                      : "${selectedEndDate!.day}-${selectedEndDate!.month}-${selectedEndDate!.year}",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16),
                ),
              ),
              const SizedBox(width: 2),
              const Icon(Icons.calendar_month, size: 25),
            ],
          ),
        ),
      ),
    );
  }


  Widget _endTimeBox() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: pickEndTime,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
          decoration: _boxDecoration(),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  selectedEndTime == null
                      ? "End Time"
                      : selectedEndTime!.format(context),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15),
                ),
              ),
              const SizedBox(width: 4),
              const Icon(Icons.access_time, size: 25),
            ],
          ),
        ),
      ),
    );
  }

  void pickEndDate() async {
    // 🚫 Start date & time must be selected first
    if (_startDateTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select start date & time first")),
      );
      return;
    }

    final DateTime start = _startDateTime!;
    final DateTime activeTill = widget.car.activeTill;

    // 🔒 Earliest end date must be AFTER start date-time
    final DateTime firstAllowedDate = DateTime(
      start.year,
      start.month,
      start.day,
    );

    // If start time is late in the day, end date may need to be next day
    final DateTime minEndDate =
    start.isAfter(firstAllowedDate) ? start : firstAllowedDate;

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: minEndDate,
      firstDate: minEndDate,
      lastDate: activeTill,

      // 🔒 Disable invalid days
      selectableDayPredicate: (day) {
        final DateTime d = DateTime(day.year, day.month, day.day);
        return !d.isBefore(firstAllowedDate) && !d.isAfter(activeTill);
      },
    );

    if (picked == null) return;

    setState(() {
      selectedEndDate = picked;
      selectedEndTime = null; // 🔁 reset time when date changes
    });
  }


  void pickEndTime() async {
    // 🚫 End date must be selected first
    if (selectedEndDate == null || _startDateTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select end date first")),
      );
      return;
    }

    final TimeOfDay? time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (time == null) return;

    final DateTime endDateTime = DateTime(
      selectedEndDate!.year,
      selectedEndDate!.month,
      selectedEndDate!.day,
      time.hour,
      time.minute,
    );

    // 🚫 End time must be AFTER start date & time
    if (!endDateTime.isAfter(_startDateTime!)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("End time must be after start time"),
        ),
      );
      return;
    }

    // 🚫 End time must NOT exceed car availability
    if (endDateTime.isAfter(widget.car.activeTill)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("End time exceeds car availability"),
        ),
      );
      return;
    }

    // ✅ Valid end time
    setState(() {
      selectedEndTime = time;
    });
  }



  BoxDecoration _boxDecoration() {
    return BoxDecoration(
      color: Colors.grey.shade100,
      borderRadius: BorderRadius.circular(12),
    );
  }

  Widget _paymentMethodTile({
    required String title,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: selected ? const Color(0xFF00A86B) : Colors.grey.shade300,
            width: 1.4),
        color: selected ? const Color(0xFFEFFBF5) : Colors.white,
      ),
      child: InkWell(
        onTap: onTap,
        child: Row(
          children: [
            Icon(icon, size: 35, color: Colors.black87),
            const SizedBox(width: 16),
            Text(title,
                style: const TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w600)),
            const Spacer(),
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: selected ? const Color(0xFF00A86B) : Colors.grey,
            ),
          ],
        ),
      ),
    );
  }

  Widget _creditCardForm() {
    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          TextField(
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: "Card Number",
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10)),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: "Expiry (MM/YY)",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: "CVV",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _priceRow(String label, String value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: bold ? Colors.black87 : Colors.grey.shade600,
                fontWeight: bold ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: bold ? 18 : 15,
              fontWeight: bold ? FontWeight.bold : FontWeight.w600,
              color: bold ? Colors.black : Colors.black87,
            ),
          ),
        ],
      ),
    );
  }


  Widget _paymentMethodDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<PaymentMethod>(
          value: selectedPaymentMethod,
          isExpanded: true,
          icon: const Icon(Icons.keyboard_arrow_down_rounded),
          borderRadius: BorderRadius.circular(16),
          onChanged: (value) {
            if (value == null) return;
            setState(() {
              selectedPaymentMethod = value;
            });
          },
          items: PaymentMethod.values.map((method) {
            return DropdownMenuItem(
              value: method,
              child: Row(
                children: [
                  Icon(
                    _iconForMethod(method),
                    size: 22,
                    color: Colors.black87,
                  ),
                  const SizedBox(width: 12),
                  Text(_labelForMethod(method)),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  String get paymentLabel {
    switch (selectedPaymentMethod) {
      case PaymentMethod.card:
        return "Credit / Debit Card";
      case PaymentMethod.applePay:
        return "Apple Pay";
      case PaymentMethod.googlePay:
        return "Google Pay";
      case PaymentMethod.paypal:
        return "PayPal";
    }
  }

  IconData get paymentIcon {
    switch (selectedPaymentMethod) {
      case PaymentMethod.card:
        return Icons.credit_card;
      case PaymentMethod.applePay:
        return Icons.phone_iphone;
      case PaymentMethod.googlePay:
        return Icons.android;
      case PaymentMethod.paypal:
        return Icons.account_balance_wallet;
    }
  }


  String _labelForMethod(PaymentMethod method) {
    switch (method) {
      case PaymentMethod.card:
        return "Credit / Debit Card";
      case PaymentMethod.applePay:
        return "Apple Pay";
      case PaymentMethod.googlePay:
        return "Google Pay";
      case PaymentMethod.paypal:
        return "PayPal";
    }
  }

  IconData _iconForMethod(PaymentMethod method) {
    switch (method) {
      case PaymentMethod.card:
        return Icons.credit_card;
      case PaymentMethod.applePay:
        return Icons.phone_iphone;
      case PaymentMethod.googlePay:
        return Icons.android;
      case PaymentMethod.paypal:
        return Icons.account_balance_wallet;
    }
  }


  Widget _bottomPayButton(double total) {
    final bool enabled = isFormComplete;

    return Container(
      padding: const EdgeInsets.all(16),
      height: 100,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
          enabled ? Colors.green : Colors.green.withOpacity(0.45),
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: enabled
            ? () async {
          if (selectedPaymentMethod == PaymentMethod.paypal) {
            await _handlePayPalPayment(total);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("Selected payment method not implemented"),
              ),
            );
          }
        }
            : null,
        child: Text(
          "Pay \$${total.toStringAsFixed(2)} →",
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }


  Future<void> _handlePayPalPayment(double total) async {
    try {
      final response = await PaymentService.createPayPalOrder(
        amount: total,
        carId: widget.car.id,
        userId: 190,
       // durationType: "D",
        //duration: 1,
        pickupAddress: selectedAddress ?? "",
        bookedFrom: _startDateTime!.toUtc().toIso8601String(),
        bookedTill: _endDateTime!.toUtc().toIso8601String(),
        pickupLat: selectedLat,
        pickupLong: selectedLng, id: '',
      );

      print("PAYPAL RESPONSE: $response");

      // ✅ Use direct response (NOT response["data"])
      final orderId = response["id"];

      final approvalUrl = response["links"]
          .firstWhere((l) => l["rel"] == "approve")["href"];

      final success = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PayPalWebViewScreen(
            approvalUrl: approvalUrl,
            orderId: orderId,
          ),
        ),
      );

      if (success == true) {
        //await PaymentService.capturePayPalOrder(orderId);

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => PaymentSuccessScreen(
              bookingId: response["_result"]?["id"], // if exists
              orderId: orderId,
              amount: total,
            ),
          ),
        );
      }
    } catch (e) {
      print("PAYMENT ERROR: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Payment failed: $e")),
      );
    }
  }


  void pickDate() async {
    final DateTime activeTill = widget.car.activeTill;
    final DateTime today = DateTime.now();

    // Safety: if availability already expired
    if (activeTill.isBefore(today)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Car is no longer available")),
      );
      return;
    }

    DateTime? date = await showDatePicker(
      context: context,
      initialDate: today,
      firstDate: today,

      // 🔒 hard limit from API
      lastDate: activeTill,

      // 🔒 disable dates after activeTill
      selectableDayPredicate: (day) {
        final tillDate = DateTime(
          activeTill.year,
          activeTill.month,
          activeTill.day,
        );
        return !day.isAfter(tillDate);
      },
    );

    if (date == null) return;

    setState(() {
      selectedDate = date;
      selectedTime = null; // reset time when date changes
    });
  }

  bool get isFormComplete {
    // Date & Time must be selected
    if (selectedDate == null || selectedTime == null) return false;

    // Pickup enabled → address required
    if (collectFromPickup) {
      if (selectedAddress == null ||
          selectedLat == null ||
          selectedLng == null) {
        return false;
      }
    }

    return true;
  }

  void pickTime() async {
    if (selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select date first")),
      );
      return;
    }

    TimeOfDay? time =
    await showTimePicker(context: context, initialTime: TimeOfDay.now());

    if (time == null) return;

    final now = DateTime.now();

    final selectedDateTime = DateTime(
      selectedDate!.year,
      selectedDate!.month,
      selectedDate!.day,
      time.hour,
      time.minute,
    );

    // 🚫 If selected date is TODAY and time is in the past
    if (selectedDate!.year == now.year &&
        selectedDate!.month == now.month &&
        selectedDate!.day == now.day &&
        selectedDateTime.isBefore(now)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select a future time")),
      );
      return;
    }

    // 🚫 Must be at least 2 hours before activeTill
    final DateTime activeTill = widget.car.activeTill;
    final DateTime minEndRequired =
    selectedDateTime.add(const Duration(hours: 2));

    if (minEndRequired.isAfter(activeTill)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Start time must be at least 2 hours before end time"),
        ),
      );
      return;
    }

    setState(() => selectedTime = time);
  }

  String get rentTypeFromDuration {
    final duration = tripDuration;
    if (duration == null) return "Hour";

    final hours = duration.inMinutes / 60;

    if (hours < 24) {
      return "Hour";
    } else if (hours < 24 * 7) {
      return "Day";
    } else {
      return "Week";
    }
  }

  bool get isTripSelected =>
      _startDateTime != null && _endDateTime != null;

  String getPriceText(CarItem car) {
    if (car.weeklyCost != null && car.weeklyCost! > 0) {
      return "\$${car.weeklyCost!.toStringAsFixed(2)}/week";
    }

    if (car.dailyCost != null && car.dailyCost! > 0) {
      return "\$${car.dailyCost!.toStringAsFixed(2)}/day";
    }

    if (car.hourlyCost != null && car.hourlyCost! > 0) {
      return "\$${car.hourlyCost!.toStringAsFixed(2)}/hr";
    }

    return "Price not available";
  }

}
