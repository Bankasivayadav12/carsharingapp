import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_places_flutter/google_places_flutter.dart';
import 'package:google_places_flutter/model/prediction.dart';

import '../controller/share_car_controller.dart';
import '../controller/HostCarShare_Preferences.dart';

class ShareCarPage extends StatefulWidget {
  final Map<String, dynamic> car;

  ShareCarPage({super.key, required this.car});

  final HostCarSharePreferencesController prefController =
  Get.put(HostCarSharePreferencesController());

  @override
  State<ShareCarPage> createState() => _ShareCarPageState();
}
enum TripType { hourly, daily, weekly }
class _ShareCarPageState extends State<ShareCarPage> {
  final ShareCarController controller = Get.put(ShareCarController());

  final TextEditingController hourlyCtrl = TextEditingController();
  final TextEditingController dailyCtrl = TextEditingController();
  final TextEditingController weeklyCtrl = TextEditingController();
  final TextEditingController pickupCtrl = TextEditingController();
  final RxString selectedAvailability = "HOURLY".obs;

  DateTime? startDateTime;
  DateTime? endDateTime;

  final startDateCtrl = TextEditingController();
  final startTimeCtrl = TextEditingController();
  final endDateCtrl = TextEditingController();
  final endTimeCtrl = TextEditingController();

  final minCtrl = TextEditingController();
  final maxCtrl = TextEditingController();
  final selectedTripType = Rx<TripType?>(null);

  double? currentLat;
  double? currentLng;

  List<int> selectedPrefIds = [];

  /// 🔑 EDIT MODE
  bool get isEdit => widget.car["is_active"] == true;

  @override
  void initState() {
    super.initState();

    final now = DateTime.now();

    // ✅ Store full trip start datetime
    startDateTime = now;

    // ✅ Set start date text
    startDateCtrl.text =
    "${now.day.toString().padLeft(2, '0')}-"
        "${now.month.toString().padLeft(2, '0')}-"
        "${now.year}";

    // ✅ Delay time formatting until context is ready
    WidgetsBinding.instance.addPostFrameCallback((_) {
      startTimeCtrl.text = TimeOfDay.fromDateTime(now).format(context);
    });

    if (isEdit) {
      _prefillFromCar();
    } else {
      _loadCurrentLocation();
    }
  }



  // ===============================================================
  // 🔄 PREFILL DATA (ACTIVE CAR)
  // ===============================================================
  void _prefillFromCar() {
    final car = widget.car;

    hourlyCtrl.text = car["hourly_cost"]?.toString() ?? "";
    dailyCtrl.text = car["daily_cost"]?.toString() ?? "";
    weeklyCtrl.text = car["weekly_cost"]?.toString() ?? "";

    pickupCtrl.text = car["address"] ?? "";

    // ✅ SET LAT/LONG FOR EDIT
    currentLat = car["lat"];
    currentLng = car["long"];

    if (car["preferences"] != null &&
        car["preferences"].toString().isNotEmpty) {
      selectedPrefIds = car["preferences"]
          .toString()
          .split(",")
          .map((e) => int.parse(e))
          .toList();
    }

    setState(() {});
  }


  // ===============================================================
  // 📍 LOCATION FOR NEW SHARE
  // ===============================================================
  Future<void> _loadCurrentLocation() async {
    final permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) return;

    final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    currentLat = pos.latitude;
    currentLng = pos.longitude;

    final placemarks =
    await placemarkFromCoordinates(pos.latitude, pos.longitude);

    final place = placemarks.first;
    pickupCtrl.text =
    "${place.street}, ${place.locality}, ${place.administrativeArea}";
    setState(() {});
  }

  // ===============================================================
  // UI
  // ===============================================================
  @override
  Widget build(BuildContext context) {
    final car = widget.car;

    return Scaffold(
      backgroundColor: const Color(0xfff7f8fa),
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: Text(isEdit ? "Edit Car Share" : "Share Your Car"),
      ),
      body: Obx(() {
        return Stack(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _title("Car"),
                  const SizedBox(height: 12),
                  _carPreview(car),

                  const SizedBox(height: 20),
                  Text(
                    "${car["name"] ?? ""} • ${car["number"] ?? ""}",
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700),
                  ),

                  const SizedBox(height: 25),
                  _title("Pickup Location"),
                  const SizedBox(height: 10),
                  _pickupSearchField(),
                  const SizedBox(height: 10),
                  _currentLocationButton(),
                  const SizedBox(height: 25),
                  _title("Trip Availability"),

                  const SizedBox(height: 16),

                  _titleSmall("Trip Start"),
                  Row(
                    children: [
                      Expanded(child: _readOnlyField("Date", startDateCtrl)),
                      const SizedBox(width: 12),
                      Expanded(child: _readOnlyFieldTime("Time", startTimeCtrl)),
                    ],
                  ),

                  const SizedBox(height: 16),

                  _titleSmall("Trip End"),
                  Row(
                    children: [
                      Expanded(
                        child: _datePickerField(
                          context,
                          "Date",
                          endDateCtrl,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _timePickerField(
                          context,
                          "Time",
                          endTimeCtrl,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 25),
                  _title("Pricing"),

                  Obx(() {
                    final type = selectedTripType.value;

                    return Column(
                      children: [
                        // HOURLY → always visible
                        _pricingField("Hourly Cost (\$)", hourlyCtrl),

                        // DAILY → visible for daily & weekly
                        if (type == TripType.daily || type == TripType.weekly)
                          _pricingField("Daily Cost (\$)", dailyCtrl),

                        // WEEKLY → visible only for weekly
                        if (type == TripType.weekly)
                          _pricingField("Weekly Cost (\$)", weeklyCtrl),
                      ],
                    );
                  }),

                  const SizedBox(height: 12),
                  _title("Preferences"),
                  const SizedBox(height: 12),
                  _preferenceChips(),

                  const SizedBox(height: 30),
                  _submitButton(car),
                ],
              ),
            ),

            if (controller.isLoading.value)
              Container(
                color: Colors.black45,
                child: const Center(
                  child: CircularProgressIndicator(color: Colors.white),
                ),
              ),
          ],
        );
      }),
    );
  }

  // ===============================================================
  // 📍 PICKUP SEARCH
  // ===============================================================
  Widget _pickupSearchField() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: GooglePlaceAutoCompleteTextField(
        textEditingController: pickupCtrl,
        googleAPIKey: "AIzaSyB08PuFrEY0Hp2GSz4MzGKx18TUSZR8HPI",
        debounceTime: 300,
        countries: const ["in"],
        isLatLngRequired: true,
        inputDecoration: const InputDecoration(
          border: InputBorder.none,
          hintText: "Search pickup location",
        ),

        itemClick: (Prediction p) {
          pickupCtrl.text = p.description!;
          pickupCtrl.selection = TextSelection.fromPosition(
            TextPosition(offset: p.description!.length),
          );
        },

        /// ✅ SAVE LAT / LNG HERE
        getPlaceDetailWithLatLng: (place) {
          controller.pickupLat = place.lat as double?;
          controller.pickupLng = place.lng as double?;

          debugPrint(
            "📍 PICKUP (SEARCH): "
                "${controller.pickupLat}, ${controller.pickupLng}",
          );
        },
      ),
    );
  }



  Widget _currentLocationButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        icon: const Icon(Icons.my_location, color: Colors.green),
        label: const Text(
          "Use Current Location",
          style: TextStyle(color: Colors.green, fontWeight: FontWeight.w600),
        ),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Colors.green),
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        onPressed: () async {
          try {
            controller.isLoading.value = true;

            final pos = await controller.getCurrentLocation();

            /// ✅ SAVE LAT / LNG
            controller.pickupLat = pos.latitude;
            controller.pickupLng = pos.longitude;

            final placemarks = await placemarkFromCoordinates(
              pos.latitude,
              pos.longitude,
            );

            final place = placemarks.first;

            pickupCtrl.text = [
              place.subLocality,
              place.locality,
              place.administrativeArea,
            ].where((e) => e != null && e!.isNotEmpty).join(", ");

            /// ✅ FETCH NEARBY CARS
            controller.fetchNearbyCars(
              pos.latitude,
              pos.longitude,
            );

            debugPrint(
              "📍 PICKUP (CURRENT): "
                  "${controller.pickupLat}, ${controller.pickupLng}",
            );
          } catch (e) {
            Get.snackbar(
              "Location Error",
              e.toString(),
              backgroundColor: Colors.red.shade100,
            );
          } finally {
            controller.isLoading.value = false;
          }
        },
      ),
    );
  }

//   availability widgets


  Widget _readOnlyField(String label, TextEditingController ctrl) {
    // ✅ Set current date
    final now = DateTime.now();
    ctrl.text = "${now.day.toString().padLeft(2, '0')}-"
        "${now.month.toString().padLeft(2, '0')}-"
        "${now.year}";

    return TextFormField(
      controller: ctrl,
      readOnly: true,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
  Widget _readOnlyFieldTime(String label, TextEditingController ctrl) {
    final now = DateTime.now();

    final hour = now.hour % 12 == 0 ? 12 : now.hour % 12;
    final period = now.hour >= 12 ? "PM" : "AM";

    ctrl.text =
    "${hour.toString().padLeft(2, '0')}:"
        "${now.minute.toString().padLeft(2, '0')} $period";

    return TextFormField(
      controller: ctrl,
      readOnly: true,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }


  Widget _datePickerField(
      BuildContext context,
      String label,
      TextEditingController ctrl,
      ) {
    return TextFormField(
      controller: ctrl,
      readOnly: true,
      onTap: () async {
        FocusScope.of(context).unfocus();

        final DateTime? pickedDate = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime.now(),
          lastDate: DateTime(2100),
        );

        if (pickedDate != null) {
          ctrl.text =
          "${pickedDate.day.toString().padLeft(2, '0')}-"
              "${pickedDate.month.toString().padLeft(2, '0')}-"
              "${pickedDate.year}";

          if (endDateTime != null) {
            endDateTime = DateTime(
              pickedDate.year,
              pickedDate.month,
              pickedDate.day,
              endDateTime!.hour,
              endDateTime!.minute,
            );
          } else {
            endDateTime = DateTime(
              pickedDate.year,
              pickedDate.month,
              pickedDate.day,
              0,
              0,
            );
          }

          _calculateTripType();
        }

      },
      decoration: InputDecoration(
        labelText: label,
        suffixIcon: const Icon(Icons.calendar_today),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  void _calculateTripType() {
    if (startDateTime == null || endDateTime == null) return;

    final diff = endDateTime!.difference(startDateTime!);

    if (diff.inHours < 24) {
      selectedTripType.value = TripType.hourly;
    } else if (diff.inDays < 7) {
      selectedTripType.value = TripType.daily;
    } else {
      selectedTripType.value = TripType.weekly;
    }
  }

  Widget _timePickerField(
      BuildContext context,
      String label,
      TextEditingController ctrl,
      ) {
    return TextFormField(
      controller: ctrl,
      readOnly: true,
      onTap: () async {
        FocusScope.of(context).unfocus();

        final TimeOfDay? pickedTime = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.now(),
        );

        if (pickedTime != null) {
          ctrl.text = pickedTime.format(context);

          // ✅ STEP 2: set time
          if (endDateTime != null) {
            endDateTime = DateTime(
              endDateTime!.year,
              endDateTime!.month,
              endDateTime!.day,
              pickedTime.hour,
              pickedTime.minute,
            );
          }

          _calculateTripType();
        }
      },
      decoration: InputDecoration(
        labelText: label,
        suffixIcon: const Icon(Icons.access_time),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }


  Widget _pricingField(
      String label,
      TextEditingController ctrl, {
        bool enabled = true,
      }) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: TextField(
        controller: ctrl,
        enabled: enabled,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: enabled ? Colors.white : Colors.grey.shade200,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }



  Widget _titleSmall(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 14,
            decoration: BoxDecoration(
              color: Colors.green,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 6),
          Text(
            text,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }


  // ===============================================================
  // 🚗 CAR PREVIEW
  // ===============================================================
  Widget _carPreview(Map<String, dynamic> car) {
    return Container(
      height: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.grey.shade200,
      ),
      child: Center(
        child: car["image"] != null && car["image"].toString().isNotEmpty
            ? Image.file(File(car["image"]), height: 120)
            : const Icon(Icons.directions_car,
            size: 60, color: Colors.black45),
      ),
    );
  }

  // ===============================================================
  // 💰 INPUT FIELD
  // ===============================================================
  Widget _field(String label, TextEditingController ctrl) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: TextField(
        controller: ctrl,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          border:
          OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
    );
  }

  // ===============================================================
  // ⚙️ PREFERENCES
  // ===============================================================
  Widget _preferenceChips() {
    return Obx(() {
      final prefs = widget.prefController.hostPreferences;

      if (prefs.isEmpty) {
        return const Text("Loading preferences...");
      }

      return Wrap(
        spacing: 10,
        runSpacing: 10,
        children: prefs.map((pref) {
          final selected = selectedPrefIds.contains(pref.id);
          return ChoiceChip(
            label: Text(pref.name),
            selected: selected,
            selectedColor: Colors.green,
            labelStyle:
            TextStyle(color: selected ? Colors.white : Colors.black),
            onSelected: (val) {
              setState(() {
                val
                    ? selectedPrefIds.add(pref.id)
                    : selectedPrefIds.remove(pref.id);
              });
            },
          );
        }).toList(),
      );
    });
  }

  // ===============================================================
  // 🚀 SUBMIT
  // ===============================================================
  Widget _submitButton(Map car) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 14),
        ),
        onPressed: () => _submitShareCar(car),
        child: Text(
          isEdit ? "Update Car" : "Share Car",
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
      ),
    );
  }

  Future<void> _submitShareCar(Map car) async {
    if (pickupCtrl.text.isEmpty ||
        hourlyCtrl.text.isEmpty ||
        dailyCtrl.text.isEmpty ||
        weeklyCtrl.text.isEmpty ||
        selectedPrefIds.isEmpty) {
      _toast("Please fill all details");
      return;
    }

    final hourly = double.tryParse(hourlyCtrl.text.trim());
    final daily = double.tryParse(dailyCtrl.text.trim());
    final weekly = double.tryParse(weeklyCtrl.text.trim());

    if (hourly == null || daily == null || weekly == null) {
      _toast("Please enter valid numeric values");
      return;
    }

    // ✅ CRITICAL CHECK
    if (currentLat == null || currentLng == null) {
      _toast("Location missing");
      return;
    }

    await controller.shareCar(
      id: car["id"],
      userId: 198,
      hourlyCost: hourly.roundToDouble(),
      dailyCost: daily.roundToDouble(),
      weeklyCost: weekly.roundToDouble(),
      preferences: selectedPrefIds.join(","),
      address: pickupCtrl.text.trim(),
      lat: currentLat!,
      long: currentLng!,
      activeFrom: startDateTime,   // ✅ HERE
      activeTill: endDateTime,     // ✅ HERE
    );

    if (controller.carData.value != null) {
      _toast(isEdit ? "Car Updated Successfully" : "Car Shared Successfully");
      Navigator.pop(context, true);
    } else {
      _toast("Operation failed");
    }
  }

  Widget _title(String t) =>
      Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold));

  void _toast(String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}
